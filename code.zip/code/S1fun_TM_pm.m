function S1 = S1fun_TM_pm(b)

global  pmdata  cell_num

rho =exp(b(3))+1; d = 1; sigma1 = exp(b(1)); sigma0 = exp(b(2)); 

k=length(pmdata);
for i=1:1:length(pmdata)
if pmdata(k)>0
      break
    else
        k=length(pmdata)-i;
end
end
vin=k-1; 
N = 3*(vin+1);

num = 2*N;
Q = zeros(num);
one = ones(num,1);
for i = 1:N-1
    Q(i+1,i) = i*d;
    Q(i+N+1,i+N) = i*d;
    Q(i+N,i+N+1) = rho;
end
for i = 1:N
    Q(i,i+N) = sigma1;
    Q(i+N,i) = sigma0;
end
temp = Q*one;
for i = 1:num
    Q(i,i) = -temp(i);
end
Qmod = Q;
for i = 1:num
    Qmod(i,num) = 1;
end
vec = zeros(1,num);
vec(num) = 1;
ssd = vec/Qmod;
dist = ssd(1:N)+ssd(N+1:2*N);
 
NN = min(length(pmdata),N);

pm = dist([1:NN]);

pm_b = pm + 1e-10;

if min(pm_b) <= 0
    S1 = 1e+30;
else
  if sum(pm_b) <= 0.99
   S1 = 1e+30;
  else

    S1 = 0;
    for i = 1:NN
       S1 = S1 - cell_num(i).*log(pm_b(i));
    end
  end
end

end

